# Booth Mitra Bulk Poster Generator — New Project

This is a fresh Android Studio project for the candidate-folder workflow discussed for Booth Mitra.

## Included workflow

1. Create a separate candidate folder.
2. Upload one main poster image.
3. Add PNG frames in batches, up to 200 per candidate.
4. Select each PNG and save its X position, Y position and width percentage. These settings are stored alongside that PNG and persist in the candidate folder.
5. Generate one 1280 × 1280 high-quality JPG for every saved PNG, using the same main poster for the whole batch.
6. Export all generated JPGs together as a ZIP. The ZIP contains every generated JPG, whether the batch contains 10, 15, 100 or 157 images.

## Build APK on GitHub

Upload the contents of this project to the repository root (including `.github/workflows/android.yml`). Open **Actions** and run **Build Booth Mitra Bulk Poster APK**. Download the `BoothMitra-Bulk-Poster-APK` artifact from the successful run.

## Notes

- Candidate folders and their assets are stored in the app's private storage on the Android device.
- Use the in-app ZIP export to copy a candidate's generated JPGs out of the app.
- The app uses Android's document picker, so the user chooses the source images and export location.
- This project is a fresh implementation; it does not depend on the earlier V3 project's Gradle or SDK workflow.
