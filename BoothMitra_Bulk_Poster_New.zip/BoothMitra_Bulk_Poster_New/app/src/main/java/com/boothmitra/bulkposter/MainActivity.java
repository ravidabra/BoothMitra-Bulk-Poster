package com.boothmitra.bulkposter;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private static final int PICK_POSTER=101, PICK_FRAMES=102, CREATE_ZIP=103;
    private File root, candidate, framesDir, outputDir;
    private File posterFile;
    private LinearLayout main, folderList, frameList;
    private TextView status, selectedLabel;
    private final ArrayList<File> frames = new ArrayList<>();
    private int selectedFrame=-1;
    private SeekBar xBar,yBar,sizeBar;
    private TextView xLabel,yLabel,sizeLabel;

    @Override public void onCreate(Bundle b){ super.onCreate(b);
        root=new File(getFilesDir(),"Candidates"); if(!root.exists()) root.mkdirs();
        buildUi(); refreshFolders();
    }
    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
    private TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(25,48,60)); t.setPadding(dp(2),dp(6),dp(2),dp(6)); return t; }
    private Button button(String s,Runnable r){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v->r.run()); return b; }
    private void buildUi(){
        ScrollView scroll=new ScrollView(this); main=new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL); main.setPadding(dp(16),dp(18),dp(16),dp(24)); main.setBackgroundColor(Color.rgb(242,247,246)); scroll.addView(main); setContentView(scroll);
        TextView title=text("BOOTH MITRA  |  BULK POSTER GENERATOR",22); title.setTextColor(Color.WHITE); title.setTypeface(null,1); title.setBackgroundColor(Color.rgb(7,105,99)); title.setPadding(dp(16),dp(20),dp(16),dp(20)); main.addView(title);
        main.addView(text("1. Candidate Folder",20)); main.addView(text("Har candidate ka apna folder. Poster, PNG frames aur settings usi folder mein save rahenge.",14));
        main.addView(button("+ Create New Candidate Folder",()->createFolder())); folderList=new LinearLayout(this); folderList.setOrientation(LinearLayout.VERTICAL); main.addView(folderList);
        selectedLabel=text("Abhi koi candidate select nahi hai",16); selectedLabel.setTypeface(null,1); main.addView(selectedLabel);
        main.addView(button("2. Upload Main Poster (1280 × 1280 output)",()->pickPoster()));
        main.addView(button("3. Add PNG Frames (up to 200)",()->pickFrames()));
        main.addView(text("PNG placement settings",18)); main.addView(text("Frame select karke X, Y aur size set karein. Har frame ki setting alag save hoti hai.",14));
        frameList=new LinearLayout(this); frameList.setOrientation(LinearLayout.VERTICAL); main.addView(frameList);
        xLabel=text("X position: 50%",14); main.addView(xLabel); xBar=new SeekBar(this); xBar.setMax(100); xBar.setProgress(50); main.addView(xBar);
        yLabel=text("Y position: 50%",14); main.addView(yLabel); yBar=new SeekBar(this); yBar.setMax(100); yBar.setProgress(50); main.addView(yBar);
        sizeLabel=text("PNG width: 30%",14); main.addView(sizeLabel); sizeBar=new SeekBar(this); sizeBar.setMax(100); sizeBar.setProgress(30); main.addView(sizeBar);
        xBar.setOnSeekBarChangeListener(seekListener()); yBar.setOnSeekBarChangeListener(seekListener()); sizeBar.setOnSeekBarChangeListener(seekListener());
        main.addView(button("Save placement for selected PNG",()->savePlacement()));
        main.addView(text("4. Generate all posters",20)); main.addView(text("Ek hi main poster har saved PNG frame par apply hoga. Har result alag 1280 × 1280 high-quality JPG hoga.",14));
        main.addView(button("Generate ALL JPG Posters",()->generateAll()));
        main.addView(button("Download / Export all JPGs as ZIP",()->exportZip()));
        status=text("Ready",14); status.setTextColor(Color.rgb(0,105,95)); main.addView(status);
    }
    private SeekBar.OnSeekBarChangeListener seekListener(){ return new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){ updateLabels(); } public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} }; }
    private void updateLabels(){ xLabel.setText("X position: "+xBar.getProgress()+"%"); yLabel.setText("Y position: "+yBar.getProgress()+"%"); sizeLabel.setText("PNG width: "+(10+sizeBar.getProgress())+"%"); }
    private void say(String s){ status.setText(s); }
    private void createFolder(){ EditText input=new EditText(this); input.setHint("Candidate name"); new AlertDialog.Builder(this).setTitle("New Candidate Folder").setView(input).setPositiveButton("Create",(d,w)->{ String n=input.getText().toString().trim().replaceAll("[^a-zA-Z0-9 _-]","").replace(' ','_'); if(n.isEmpty()){say("Candidate name required");return;} File f=new File(root,n); if(!f.exists()) f.mkdirs(); selectCandidate(f); refreshFolders(); }).setNegativeButton("Cancel",null).show(); }
    private void refreshFolders(){ folderList.removeAllViews(); File[] fs=root.listFiles(File::isDirectory); if(fs!=null) for(File f:fs){ Button b=button("Open: "+f.getName(),()->selectCandidate(f)); folderList.addView(b); } }
    private void selectCandidate(File f){ candidate=f; framesDir=new File(f,"PNG_Frames"); outputDir=new File(f,"HD_JPG_Output"); framesDir.mkdirs(); outputDir.mkdirs(); posterFile=new File(f,"Main_Poster"); if(!posterFile.exists()) posterFile=null; selectedLabel.setText("Selected Candidate: "+f.getName()); loadFrames(); say("Candidate folder ready: "+f.getName()); }
    private boolean needCandidate(){ if(candidate==null){say("Pehle Candidate Folder create ya select karein.");return false;} return true; }
    private void pickPoster(){ if(!needCandidate())return; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_POSTER); }
    private void pickFrames(){ if(!needCandidate())return; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/png"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_FRAMES); }
    @Override protected void onActivityResult(int req,int res,Intent data){ super.onActivityResult(req,res,data); if(res!=RESULT_OK||data==null)return;
        try{
            if(req==PICK_POSTER){ Uri u=data.getData(); File dst=new File(candidate,"Main_Poster"); copyUri(u,dst); posterFile=dst; say("Main poster saved."); }
            else if(req==CREATE_ZIP){ writeZip(data.getData()); say("ZIP export complete."); }
            else if(req==PICK_FRAMES){ ArrayList<Uri> uris=new ArrayList<>(); if(data.getClipData()!=null){ for(int k=0;k<data.getClipData().getItemCount();k++) uris.add(data.getClipData().getItemAt(k).getUri()); } else if(data.getData()!=null) uris.add(data.getData()); int added=0; for(Uri u:uris){ if(frames.size()>=200)break; String name=displayName(u); if(!name.toLowerCase().endsWith(".png")) name+=".png"; File dst=new File(framesDir,System.currentTimeMillis()+"_"+safe(name)); copyUri(u,dst); frames.add(dst); added++; } refreshFrameList(); say(added+" PNG frame(s) saved. Total: "+frames.size()+"/200"); }
        }catch(Exception e){ say("Import error: "+e.getMessage()); }
    }
    private String safe(String s){ return s.replaceAll("[^a-zA-Z0-9._-]","_"); }
    private String displayName(Uri u){ String n="frame.png"; Cursor c=getContentResolver().query(u,null,null,null,null); if(c!=null){try{if(c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0)n=c.getString(x);}}finally{c.close();}} return n; }
    private void copyUri(Uri u,File dst)throws Exception{ try(InputStream in=getContentResolver().openInputStream(u); OutputStream out=new FileOutputStream(dst)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);} }
    private void loadFrames(){ frames.clear(); File[] fs=framesDir.listFiles((d,n)->n.toLowerCase().endsWith(".png")); if(fs!=null){Arrays.sort(fs);frames.addAll(Arrays.asList(fs));} selectedFrame=-1; refreshFrameList(); }
    private void refreshFrameList(){ if(frameList==null)return; frameList.removeAllViews(); for(int i=0;i<frames.size();i++){ final int idx=i; Button b=button((i+1)+". "+frames.get(i).getName(),()->selectFrame(idx)); frameList.addView(b); } }
    private Properties props(File f){ Properties p=new Properties(); File pf=new File(f.getAbsolutePath()+".properties"); if(pf.exists())try(FileInputStream in=new FileInputStream(pf)){p.load(in);}catch(Exception ignored){} return p; }
    private void selectFrame(int idx){ selectedFrame=idx; Properties p=props(frames.get(idx)); xBar.setProgress(parse(p.getProperty("x"),50)); yBar.setProgress(parse(p.getProperty("y"),50)); sizeBar.setProgress(Math.max(0,Math.min(90,parse(p.getProperty("size"),30)-10))); updateLabels(); say("Selected PNG: "+frames.get(idx).getName()); }
    private int parse(String s,int d){try{return Integer.parseInt(s);}catch(Exception e){return d;}}
    private void savePlacement(){ if(selectedFrame<0){say("Pehle PNG frame select karein.");return;} Properties p=new Properties(); p.setProperty("x",String.valueOf(xBar.getProgress())); p.setProperty("y",String.valueOf(yBar.getProgress())); p.setProperty("size",String.valueOf(10+sizeBar.getProgress())); try(FileOutputStream out=new FileOutputStream(frames.get(selectedFrame).getAbsolutePath()+".properties")){p.store(out,"Booth Mitra frame placement");say("Placement saved for selected PNG.");}catch(Exception e){say("Save error: "+e.getMessage());} }
    private Bitmap decode(File f){ BitmapFactory.Options o=new BitmapFactory.Options(); o.inPreferredConfig=Bitmap.Config.ARGB_8888; return BitmapFactory.decodeFile(f.getAbsolutePath(),o); }
    private void generateAll(){ if(!needCandidate())return; if(posterFile==null||!posterFile.exists()){say("Main poster upload karein.");return;} if(frames.isEmpty()){say("Kam se kam 1 PNG frame add karein.");return;} new Thread(()->{ int done=0; try{ Bitmap source=decode(posterFile); if(source==null)throw new Exception("Poster image read nahi ho paayi"); for(File frame:frames){ Bitmap overlay=decode(frame); if(overlay==null)continue; Properties p=props(frame); int x=parse(p.getProperty("x"),50), y=parse(p.getProperty("y"),50), width=parse(p.getProperty("size"),30); Bitmap out=Bitmap.createBitmap(1280,1280,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(out); c.drawColor(Color.WHITE); Rect src=new Rect(); int sw=source.getWidth(), sh=source.getHeight(); float scale=Math.max(1280f/sw,1280f/sh); int cw=(int)(1280/scale), ch=(int)(1280/scale); src.set((sw-cw)/2,(sh-ch)/2,(sw+cw)/2,(sh+ch)/2); c.drawBitmap(source,src,new Rect(0,0,1280,1280),new Paint(Paint.FILTER_BITMAP_FLAG|Paint.ANTI_ALIAS_FLAG)); int ow=Math.max(1,(int)(1280f*width/100f)); float ratio=(float)overlay.getHeight()/overlay.getWidth(); int oh=Math.max(1,(int)(ow*ratio)); int left=(int)((1280-ow)*x/100f), top=(int)((1280-oh)*y/100f); c.drawBitmap(overlay,null,new Rect(left,top,left+ow,top+oh),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG)); String base=frame.getName().replaceAll("(?i)\\.png$",""); File dest=new File(outputDir,base+".jpg"); try(FileOutputStream fos=new FileOutputStream(dest)){out.compress(Bitmap.CompressFormat.JPEG,100,fos);} out.recycle(); overlay.recycle(); done++; } source.recycle(); final int count=done; runOnUiThread(()->say("Complete: "+count+" HD JPG posters generated.")); }catch(Exception e){runOnUiThread(()->say("Generate error: "+e.getMessage()));} }).start(); say("Generating posters… please wait."); }
    private void exportZip(){ if(!needCandidate())return; File[] jpgs=outputDir.listFiles((d,n)->n.toLowerCase().endsWith(".jpg")); if(jpgs==null||jpgs.length==0){say("Pehle Generate ALL JPG Posters karein.");return;} Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip"); i.putExtra(Intent.EXTRA_TITLE,candidate.getName()+"_HD_Posters.zip"); startActivityForResult(i,CREATE_ZIP); }
    private void writeZip(Uri uri)throws Exception{ try(OutputStream raw=getContentResolver().openOutputStream(uri); ZipOutputStream zip=new ZipOutputStream(raw)){ File[] fs=outputDir.listFiles((d,n)->n.toLowerCase().endsWith(".jpg")); if(fs!=null)for(File f:fs){zip.putNextEntry(new ZipEntry(f.getName()));try(InputStream in=new FileInputStream(f)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)zip.write(b,0,n);}zip.closeEntry();} } }
}
