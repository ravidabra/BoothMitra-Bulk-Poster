# Booth Mitra V3 Android

Android WebView app for candidate-wise poster projects.

Features:
- Separate candidate folders stored locally on the device (IndexedDB)
- One shared 1280x1280 poster per candidate project
- Save one master PNG overlay position and reuse it for every frame
- Add 1–200 transparent PNG frames, append more later, and retain them
- Generate one JPG per PNG frame at 1280x1280 or 3840x3840
- Download individual JPGs or all generated JPGs as a ZIP
- Export files to Android Downloads through a native bridge

Build:
- Push this project to GitHub.
- GitHub Actions workflow builds `app-debug.apk`.
- Download artifact `BoothMitra-V3-Android-APK`.

Important:
- App data is stored on the device. Use Android app backup/device transfer where supported; an in-app portable backup/export feature is a future enhancement.
- Keep the app open during large batches, especially 4K exports.
- 4K export is upscaled from the source poster; it cannot restore detail absent from the original.
