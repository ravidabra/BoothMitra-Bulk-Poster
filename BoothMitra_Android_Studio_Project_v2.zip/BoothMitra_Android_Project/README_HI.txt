BOOTH MITRA BULK POSTER GENERATOR — ANDROID STUDIO PROJECT

यह Android Studio में APK बनाने के लिए तैयार source project है; यह compiled APK नहीं है।

इसमें:
- Android launcher activity और app label
- लोकल WebView में Dual Photo Poster Generator
- एक template, बाएँ और दाएँ नेताओं की अलग photo lists
- दोनों फ्रेम अलग-अलग move/resize/zoom
- ZIP download listener
- Android file picker से multi-select image upload

APK बनाने के लिए:
1. Android Studio (latest stable) में यह पूरा folder खोलें।
2. Gradle sync पूरा होने दें।
3. Android SDK Platform 35 और उपयुक्त Build Tools इंस्टॉल हों।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।
6. फोन में APK भेजकर install करें। फोन में "Install unknown apps" की अनुमति देनी पड़ सकती है।

महत्वपूर्ण:
- इस ChatGPT execution environment में Android SDK/Gradle build tool उपलब्ध नहीं है, इसलिए यहाँ signed/compiled APK बनाकर देना संभव नहीं हुआ।
- index.html में ZIP library CDN से आती है; ZIP बनाने के समय इंटरनेट चाहिए।
- Release/Play Store APK के लिए अपना signing keystore और release build जरूरी है।
