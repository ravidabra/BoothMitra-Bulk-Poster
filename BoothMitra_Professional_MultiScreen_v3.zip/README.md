# Booth Mitra Professional Multi-Screen App
Blank-screen correction: MainActivity now calls show(1) from onCreate() to display the Candidate Projects screen.
Original supplied Booth Mitra logo remains unchanged.
Screens: Candidate Projects, Main Poster Preview, PNG Library + shared Master Position, Generate, Results/ZIP.
Application ID: com.boothmitra.bulkposter
Build: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK 35.
