# Booth Mitra Professional Bulk Poster Studio

Native Android project with five screens:
1. Candidate projects
2. Main poster upload and preview
3. PNG library (up to 200) with one shared Master Position
4. Batch generation with HD 1280x1280 or 4K 3840x3840 output
5. Results, save JPGs, and export all as ZIP

The original user-provided Booth Mitra logo is included unchanged at:
`app/src/main/res/drawable-nodpi/booth_mitra_logo.png`

Brand colors remain teal and red from the supplied logo. Application ID: `com.boothmitra.bulkposter`.

Build requirements: JDK 17, Gradle 8.9, Android SDK 35, Android Gradle Plugin 8.7.3.
